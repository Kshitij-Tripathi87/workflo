"""Probe generator — produces default configs and pytest files from configs.

The generator is what makes workflo work on "any Python repo, not just
one hardcoded example" (Claim #1). Given a repo URL, it produces a default
probe config tuned for a B2B SaaS API. The user can then tweak the YAML
without writing Python.
"""

from __future__ import annotations

from textwrap import dedent

from probe_engine.models import ProbeConfig, ProbeSpec


class ProbeGenerator:
    """Generate default probe configs and pytest test files."""

    # ============================================================
    # SECURITY PROBES (renamed from DEFAULT_API_PROBES)
    # ============================================================
    DEFAULT_SECURITY_PROBES = [
        ProbeSpec(
            name="cross_tenant_read_denied",
            pattern="api_read",
            path="/api/v1/projects",
            method="GET",
            expected_status=[403, 404],
            soc2_controls=["CC6.1", "CC6.6"],
            description="Cross-tenant resource read is denied",
        ),
        ProbeSpec(
            name="cross_tenant_list_excluded",
            pattern="api_list",
            path="/api/v1/projects",
            method="GET",
            list_key="projects",
            expect_resource_absent=True,
            expected_status=200,
            soc2_controls=["CC6.1", "CC6.6"],
            description="Cross-tenant resources excluded from list responses",
        ),
        ProbeSpec(
            name="cross_tenant_modify_denied",
            pattern="api_modify",
            path="/api/v1/projects",
            method="PUT",
            expected_status=[403, 404],
            soc2_controls=["CC6.1", "CC6.6"],
            description="Cross-tenant resource modification is denied",
        ),
        ProbeSpec(
            name="cross_tenant_delete_denied",
            pattern="api_delete",
            path="/api/v1/projects",
            method="DELETE",
            expected_status=[403, 404],
            soc2_controls=["CC6.1", "CC6.6"],
            description="Cross-tenant resource deletion is denied",
        ),
        ProbeSpec(
            name="positive_control_same_tenant",
            pattern="positive_control",
            path="/api/v1/projects",
            method="GET",
            expected_status=200,
            soc2_controls=["CC6.1"],
            description="Same-tenant access succeeds (validates the test itself)",
        ),
    ]

    # ============================================================
    # FUNCTIONAL PROBE GROUPS
    # ============================================================
    DEFAULT_SURFACE_PROBES = [
        ProbeSpec(
            name="native_pytest_suite",
            pattern="pytest_execution",
            path="/", method="EXEC",
            expected_status=0,
            soc2_controls=[],
            description="Execute repository's native pytest suite",
        ),
        ProbeSpec(
            name="import_smoke_test",
            pattern="import_check",
            path="/", method="EXEC",
            expected_status=0,
            soc2_controls=[],
            description="Verify package imports without errors",
        ),
        ProbeSpec(
            name="basic_api_reachability",
            pattern="api_reachability",
            path="/health", method="GET",
            expected_status=200,
            soc2_controls=[],
            description="Basic API endpoint reachability",
        ),
    ]

    DEFAULT_DEEP_PROBES = [
        *DEFAULT_SURFACE_PROBES,
        ProbeSpec(
            name="generated_contract_tests",
            pattern="contract_test",
            path="/api/v1", method="EXEC",
            expected_status=0,
            soc2_controls=[],
            description="LLM-generated OpenAPI contract tests (Phase 2+)",
        ),
        ProbeSpec(
            name="generated_edge_cases",
            pattern="edge_case",
            path="/", method="EXEC",
            expected_status=0,
            soc2_controls=[],
            description="LLM-generated edge case tests (Phase 2+)",
        ),
    ]

    DEFAULT_AGGRESSIVE_PROBES = [
        *DEFAULT_DEEP_PROBES,
        ProbeSpec(
            name="fuzz_testing",
            pattern="fuzz",
            path="/", method="EXEC",
            expected_status=0,
            soc2_controls=[],
            description="Property-based/fuzz testing (Phase 2+)",
        ),
        ProbeSpec(
            name="chaos_testing",
            pattern="chaos",
            path="/", method="EXEC",
            expected_status=0,
            soc2_controls=[],
            description="Chaos engineering probes (Phase 2+)",
        ),
    ]

    # Map probe group name -> list of ProbeSpec
    PROBE_GROUPS = {
        "surface": DEFAULT_SURFACE_PROBES,
        "deep": DEFAULT_DEEP_PROBES,
        "aggressive": DEFAULT_AGGRESSIVE_PROBES,
        "security": DEFAULT_SECURITY_PROBES,
    }

    @classmethod
    def default_config(cls, repo_url: str = "", groups: list[str] = None) -> ProbeConfig:
        """Generate a default probe config for an unknown repo.

        Args:
            repo_url: Git repository URL
            groups: List of probe group names. Valid: "surface", "deep",
                    "aggressive", "security". Default: ["surface", "security"].

        Returns:
            ProbeConfig with union of all probes from specified groups.
        """
        groups = groups or ["surface", "security"]
        all_probes = []
        for group in groups:
            all_probes.extend(cls.PROBE_GROUPS.get(group, []))
        return ProbeConfig(
            name="workflo-probes",
            version="1.0",
            probes=all_probes,
            metadata={"repo_url": repo_url, "groups": ",".join(groups)},
        )

    @classmethod
    def to_yaml_str(cls, config: ProbeConfig) -> str:
        """Serialize a ProbeConfig to YAML."""
        import yaml
        return yaml.dump(
            config.model_dump(mode="json"),
            sort_keys=False,
            default_flow_style=False,
        )

    @classmethod
    def from_yaml_str(cls, yaml_str: str) -> ProbeConfig:
        """Parse YAML into a ProbeConfig."""
        return ProbeConfig.from_yaml_str(yaml_str)

    @classmethod
    def generate_pytest_file(cls, config: ProbeConfig) -> str:
        """Generate a pytest test file from a probe config.

        The generated file uses the existing `tenant_shield.api.client.APIClient`
        and `probe_engine.runner.ProbeRunner` — no hardcoded fixtures.
        """
        lines = [
            '"""Auto-generated by workflo probe engine — do not edit by hand.',
            '',
            f"Config: {config.name} (v{config.version})",
            '"""',
            '',
            'import os',
            'import pytest',
            '',
            'from tenant_shield.api.client import APIClient',
            'from probe_engine import ProbeConfig, ProbeRunner',
            '',
            '',
            '@pytest.fixture',
            'def probe_config():',
            '    return ProbeConfig(',
        ]
        lines.append(f'        name={config.name!r},')
        lines.append(f'        version={config.version!r},')
        lines.append('        probes=[')
        for probe in config.probes:
            probe_dict = probe.model_dump()
            lines.append(f'            {probe_dict!r},')
        lines.append('        ],')
        lines.append('    )')
        lines.append('')
        lines.append('')
        lines.append('@pytest.fixture')
        lines.append('def creator_client(env_config):')
        lines.append('    return APIClient(base_url=env_config.api_url, tenant_id="company1", auth_token="mock-token")')
        lines.append('')
        lines.append('')
        lines.append('@pytest.fixture')
        lines.append('def intruder_client(env_config):')
        lines.append('    return APIClient(base_url=env_config.api_url, tenant_id="company2", auth_token="mock-token")')
        lines.append('')
        lines.append('')

        for probe in config.probes:
            lines.append(f'def test_{probe.name}(probe_config, creator_client, intruder_client):')
            lines.append(f'    """{probe.description}"""')
            lines.append('    runner = ProbeRunner(probe_config)')
            lines.append('    # Create a resource first, then run probes against it')
            lines.append('    response = creator_client.post("/api/v1/projects", json={"name": "test"})')
            lines.append('    if response.status_code not in (200, 201):')
            lines.append('        pytest.skip("Cannot create resource for probing")')
            lines.append('    resource_id = response.json().get("id")')
            lines.append('    try:')
            lines.append('        summary = runner.run_all(creator_client, intruder_client, resource_id)')
            lines.append(f'        probe_result = next(r for r in summary.results if r.name == {probe.name!r})')
            lines.append('        assert probe_result.passed, f"Probe {probe.name} failed: {probe_result.detail}"')
            lines.append('    finally:')
            lines.append('        creator_client.delete(f"/api/v1/projects/{resource_id}")')
            lines.append('')
        return '\n'.join(lines)